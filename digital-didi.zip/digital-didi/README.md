# Digital Didi: quiz landing page (lean version)

Quiz -> server-side scoring -> qualified people see your Calendly calendar on `/fit` (the page you track as a Lead).
Every submission (qualified or not) is added to your Google Sheet.

## What is built and tested
- Landing page with full copy, no price anywhere
- 8-question quiz, server-side validation, honeypot and rate limit
- Scoring in `lib/scoring.ts` (edit there to change the rules)
- `/fit` is blocked unless the server issued a signed pass cookie
- Google Sheet saving (code written; needs your env vars, NOT yet tested against your real sheet)
- `/booked` thank-you page with WhatsApp button (only works if Calendly's redirect is set up on a paid plan)
- Meta Pixel, loaded only after the visitor accepts the banner
- `npm test` runs 27 automated tests (all passing)

## What is NOT built yet
Admin dashboard, Calendly webhook, email sending. Use your Google Sheet and Calendly for now.

## Deploy (Vercel)
1. Put this folder in a GitHub repository.
2. On vercel.com choose Add New > Project, import the repository.
3. Add the environment variables from `.env.example` (Settings > Environment Variables).
4. Deploy. Then open the live link and run the checklist below.

Note: check Vercel's current terms. Its free Hobby plan may not allow commercial use. Netlify or Cloudflare Pages are alternatives.

## Environment variables
See `.env.example`. Required: SIGNING_SECRET, GOOGLE_SHEET_WEBHOOK_URL, GOOGLE_SHEET_SECRET, NEXT_PUBLIC_CALENDLY_URL.
For the WhatsApp button: NEXT_PUBLIC_WHATSAPP_NUMBER (digits only, e.g. 2348012345678).

## Test checklist before running ads
1. Take the quiz as a qualified person. A new row must appear in your sheet, and the calendar must load.
2. Take it choosing "only free guidance". A row appears and no calendar shows.
3. Open `yourdomain.com/fit` in a private window. It must send you back to the quiz.
4. Choose "need to understand first". You must see the review message, no calendar.
5. Open the page on your phone and try every screen.
6. If using the Pixel: accept the banner, then check Meta Events Manager shows PageView and Lead (Lead fires on /fit).

## Known limits
- Rate limiting is in-memory, so it slows casual abuse but isn't airtight on serverless hosting.
- If Google Sheets is unreachable, the visitor still proceeds, but that row is lost (it's logged in your host's server logs).
- Privacy policy is a draft. Review it before publishing.
