import { NextRequest, NextResponse } from "next/server";
import { validate } from "@/lib/validate";
import { score } from "@/lib/scoring";
import { issuePass, COOKIE_NAME, PASS_TTL_SECONDS } from "@/lib/token";
import { tooMany } from "@/lib/rate-limit";
import { saveToSheet } from "@/lib/sheet";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  if (tooMany(ip)) {
    return NextResponse.json(
      { error: "Too many attempts. Please wait a few minutes and try again." },
      { status: 429 }
    );
  }

  const raw = await req.text();
  if (raw.length > 8000) return NextResponse.json({ error: "Request too large." }, { status: 413 });

  let body: any;
  try {
    body = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Something went wrong. Please refresh and try again." }, { status: 400 });
  }

  // Honeypot: real people never fill this hidden field. Pretend success, store nothing.
  if (typeof body?.company === "string" && body.company.trim() !== "") {
    return NextResponse.json({ result: "needs_review" });
  }

  const parsed = validate(body);
  if (!parsed.ok) return NextResponse.json({ errors: parsed.errors }, { status: 422 });

  // Result is decided here on the server, never taken from the browser.
  const result = score(parsed.data);

  // Save every submission, including not-qualified ones.
  await saveToSheet(parsed.data, result);

  const res = NextResponse.json({ result });
  if (result === "qualified") {
    res.cookies.set(COOKIE_NAME, issuePass(), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: PASS_TTL_SECONDS,
    });
  }
  return res;
}
