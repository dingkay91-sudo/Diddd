import type { Metadata } from "next";
import BookedClient from "@/components/BookedClient";
import { BRAND } from "@/lib/config";

export const metadata: Metadata = { title: `Session booked | ${BRAND}`, robots: { index: false, follow: false } };

export default function BookedPage() {
  return (
    <main className="on-paper page-pad">
      <div className="wrap narrow">
        <p className="brand">{BRAND}</p>
        <BookedClient />
      </div>
    </main>
  );
}
