import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { COOKIE_NAME, verifyPass } from "@/lib/token";
import { CALENDLY_URL, BRAND } from "@/lib/config";
import CalendlyEmbed from "@/components/CalendlyEmbed";
import TrackOnMount from "@/components/TrackOnMount";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: `Choose a time | ${BRAND}`, robots: { index: false, follow: false } };

export default function FitPage() {
  // Server-side gate: no valid signed pass, no calendar.
  const pass = cookies().get(COOKIE_NAME)?.value;
  if (!verifyPass(pass)) redirect("/#apply");

  return (
    <main className="on-paper page-pad">
      <TrackOnMount event="Lead" />
      <div className="wrap narrow">
        <p className="brand">{BRAND}</p>
        <h1 style={{ fontSize: "clamp(1.9rem, 6vw, 2.8rem)", marginTop: "1.5rem" }}>Your answers look like a good match for a conversation.</h1>
        <p className="lead">Choose a time for your 15-minute Ad Growth Opportunity Session below.</p>
        <p>We'll talk about your business, your current advertising and whether the six-week engagement could help. Please be ready to discuss your offer and your goals.</p>
        {CALENDLY_URL ? (
          <CalendlyEmbed url={CALENDLY_URL} />
        ) : (
          <div className="notice" role="alert">
            The booking calendar isn't connected yet. We'll contact you on WhatsApp or email to arrange a time.
          </div>
        )}
      </div>
    </main>
  );
}
