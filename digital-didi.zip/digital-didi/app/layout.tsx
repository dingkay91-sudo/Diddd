import type { Metadata, Viewport } from "next";
import "./globals.css";
import Tracking from "@/components/Tracking";

export const metadata: Metadata = {
  title: "Digital Didi | Six-week Meta and TikTok advertising engagement",
  description:
    "A structured six-week advertising engagement for business owners who have something to sell and want a clearer strategy behind their Meta and TikTok ads. Take the short quiz to see if a conversation makes sense.",
  openGraph: {
    title: "Digital Didi | Six-week Meta and TikTok advertising engagement",
    description: "Structured paid advertising support for business owners who want a clearer strategy.",
    type: "website",
  },
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0d2b25" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <Tracking />
      </body>
    </html>
  );
}
