import Quiz from "@/components/Quiz";
import { BRAND, FOUNDER, CAPACITY_MESSAGE, CONTACT_EMAIL } from "@/lib/config";

export default function Home() {
  return (
    <main>
      {/* 1. Hero */}
      <section className="on-ink" aria-labelledby="hero-title" style={{ paddingTop: 0, paddingBottom: 0 }}>
        <div className="wrap">
          <div className="topbar"><span className="brand">{BRAND}</span></div>
          <div className="hero">
            <h1 id="hero-title">Spending more on ads won't fix a problem you haven't diagnosed.</h1>
            <p className="lead">
              A structured six-week Meta and TikTok advertising engagement for business owners who already have
              something to sell and want a clearer strategy behind their ads.
            </p>
            {CAPACITY_MESSAGE && <p className="capacity">{CAPACITY_MESSAGE}</p>}
            <a className="btn btn-brass" href="#apply">Apply for an Ad Growth Opportunity Session</a>
            <p className="fineprint">
              Take a short quiz to see if a 15-minute call makes sense. Completing it doesn't guarantee a booking.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Problem */}
      <section className="on-paper">
        <div className="wrap prose-wide prose">
          <h2>The results don't add up, and nobody can tell you why.</h2>
          <p>
            You're running ads. Money leaves your account every day. Some weeks you get enquiries, other weeks
            nothing. Leads come in, but they don't buy. You change the audience, then the creative, then the
            budget, and you're still not sure what made the difference.
          </p>
          <p>
            So the next thought feels natural: "Maybe I just need to spend more." Sometimes that's true. Often it
            only makes an unclear problem more expensive.
          </p>
          <p>
            If the offer is confusing, the message is weak, or people drop off after they click, a bigger budget
            just sends more people into the same leak.
          </p>
        </div>
      </section>

      {/* 3. Reframe */}
      <section className="on-white">
        <div className="wrap">
          <div className="prose-wide prose">
            <h2>Ad performance is six connected parts, not one setting.</h2>
            <p>
              A weakness in one part can limit everything after it. A strong creative can't rescue an unclear
              offer. A strong offer can't survive a confusing enquiry process.
            </p>
          </div>
          <ol className="chain" aria-label="The six connected parts of ad performance">
            <li>Offer<span>What you're asking people to buy</span></li>
            <li>Audience<span>Who sees it, and why they care</span></li>
            <li>Message<span>How the value is explained</span></li>
            <li>Creative<span>What stops the scroll</span></li>
            <li>Structure and testing<span>How campaigns learn</span></li>
            <li>Conversion journey<span>What happens after the click</span></li>
          </ol>
          <p className="prose" style={{ marginTop: "1.5rem", color: "var(--muted)", maxWidth: "40rem" }}>
            These are places to investigate, not assumptions about your business. Your ads may be strong in most of
            them and held back by one.
          </p>
        </div>
      </section>

      {/* 4. Proof */}
      <section className="on-forest" aria-labelledby="proof-title">
        <div className="wrap">
          <h2 id="proof-title" style={{ color: "#fff" }}>Results from real campaigns</h2>
          <div className="proof">
            <div className="proof-item">
              <p className="proof-figure">≈₦12 million</p>
              <p>in revenue from ₦998,000 in ad spend, on one campaign.</p>
            </div>
            <div className="proof-item">
              <p className="proof-figure">₦0 to ₦1 million</p>
              <p>in revenue in nine days, for a perfume business.</p>
            </div>
            <div className="proof-item">
              <p className="proof-figure">70+ leads</p>
              <p>generated through an advertising campaign.</p>
            </div>
            <div className="proof-item">
              <p className="proof-figure">₦500,000+</p>
              <p>generated with less than ₦50,000 in ad spend.</p>
              <span className="tag">A student I trained, not a client campaign I managed.</span>
            </div>
          </div>
          <p className="proof-note">
            Each result comes from a separate campaign. Figures are revenue, not profit. These results are not
            typical or guaranteed. Outcomes vary by business, offer, market, budget, execution and other factors.
          </p>
        </div>
      </section>

      {/* 5. The engagement */}
      <section className="on-white" aria-labelledby="engage-title">
        <div className="wrap">
          <div className="prose-wide prose">
            <h2 id="engage-title">We investigate first, then build.</h2>
            <p>
              The six-week engagement moves from understanding your business to running and refining campaigns.
              Each part feeds the next.
            </p>
          </div>
          <div className="parts">
            <div className="part"><h3>Offer and positioning</h3><p>We review your products, services and offers, then recommend clearer ways to present them to the people you want to reach.</p></div>
            <div className="part"><h3>Audience and market research</h3><p>We study your customers' needs, motivations and objections, look at relevant competitors, and find advertising angles worth testing.</p></div>
            <div className="part"><h3>Creative strategy</h3><p>Hooks, concepts and scripts for your ads, with a testing direction so creative production stops being guesswork.</p></div>
            <div className="part"><h3>Ad setup and management</h3><p>Meta and/or TikTok campaigns planned around your agreed objectives, then monitored and adjusted using performance data.</p></div>
            <div className="part"><h3>Conversion-path review</h3><p>We look at what happens after someone sees your ad, find friction in your landing page, form or enquiry process, and recommend improvements.</p></div>
            <div className="part"><h3>Performance review</h3><p>We read the patterns in your campaign data, note what needs more testing, and use it to decide what to do next.</p></div>
          </div>
          <p className="scope-note">
            The exact scope is agreed on the call. The engagement doesn't automatically include a custom website,
            unlimited creatives or ad spend, and it isn't a shortcut to revenue.
          </p>
        </div>
      </section>

      {/* 6 + 7. Who it's for / not for */}
      <section className="on-paper" aria-labelledby="fit-title">
        <div className="wrap">
          <h2 id="fit-title">Who this is for, and who it isn't.</h2>
          <div className="fit-grid">
            <div>
              <h3>This is for you if you:</h3>
              <ul>
                <li>Have a real product or service to sell.</li>
                <li>Have an offer that's ready, or are willing to improve it before scaling ads.</li>
                <li>Want a more structured approach to paid advertising.</li>
                <li>Will share the information and cooperation needed to carry out a strategy.</li>
                <li>Understand that ads need an appropriate budget and results aren't guaranteed.</li>
                <li>See professional support as a business investment.</li>
              </ul>
            </div>
            <div>
              <h3>This isn't for you if you:</h3>
              <ul>
                <li>Only want free advertising advice.</li>
                <li>Have nothing ready to sell yet.</li>
                <li>Want guaranteed sales or guaranteed returns.</li>
                <li>Expect advertising alone to fix every problem in your business.</li>
                <li>Aren't willing to take part in the process or consider recommendations.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 8. The session */}
      <section className="on-white">
        <div className="wrap prose-wide prose">
          <h2>What the 15-minute Ad Growth Opportunity Session is.</h2>
          <p>It's a short conversation to:</p>
          <ul>
            <li>Talk about your business and your current advertising.</li>
            <li>Understand your main growth or conversion challenge.</li>
            <li>See whether the six-week engagement could be a good fit.</li>
            <li>Talk through next steps, and the investment if there's a potential fit.</li>
          </ul>
          <p>
            It's a fit conversation. It isn't a free audit or a full strategy session. Finishing the quiz doesn't
            guarantee a booking or acceptance.
          </p>
        </div>
      </section>

      {/* 9. Quiz */}
      <section className="on-ink" id="apply" aria-labelledby="apply-title">
        <div className="wrap narrow">
          <h2 id="apply-title" style={{ color: "#fff" }}>See if a conversation makes sense.</h2>
          <p className="lead">Eight quick questions, about two minutes. If it looks like a match, you'll go straight to the calendar.</p>
          <Quiz />
        </div>
      </section>

      {/* 10. Final CTA */}
      <section className="on-forest final">
        <div className="wrap">
          <h2>The first step is simple: tell us about your business.</h2>
          <p className="lead" style={{ maxWidth: "34rem" }}>Then we can decide together whether a conversation makes sense.</p>
          <a className="btn btn-brass" href="#apply">Apply for an Ad Growth Opportunity Session</a>
        </div>
      </section>

      {/* 11. Footer */}
      <footer className="footer">
        <div className="wrap">
          <p className="name">{BRAND}</p>
          <p>{FOUNDER}</p>
          {CONTACT_EMAIL && <p><a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></p>}
          <p><a href="/privacy">Privacy policy</a></p>
          <p style={{ marginTop: "1.25rem", maxWidth: "40rem" }}>
            Advertising results vary and are not guaranteed. Examples shown are from specific campaigns and are not
            typical.
          </p>
        </div>
      </footer>
    </main>
  );
}
