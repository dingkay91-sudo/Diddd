import type { Metadata } from "next";
import { BRAND, FOUNDER, CONTACT_EMAIL } from "@/lib/config";

export const metadata: Metadata = { title: `Privacy policy | ${BRAND}`, description: `How ${BRAND} handles information you share through the application quiz.` };

export default function Privacy() {
  return (
    <main className="on-paper page-pad">
      <div className="wrap narrow prose">
        <p className="brand"><a href="/" style={{ textDecoration: "none" }}>{BRAND}</a></p>
        <div className="notice" role="note">
          <strong>Draft for review.</strong> This is a starting point, not legal advice. Review and edit it (and
          check it against the Nigeria Data Protection Act 2023) before you rely on it. Items in [square brackets]
          need your decision.
        </div>

        <h1 style={{ fontSize: "2.2rem", marginTop: "1.5rem" }}>Privacy policy</h1>

        <h3>Who we are</h3>
        <p>{BRAND}, operated by {FOUNDER}, runs a paid advertising service for business owners. {CONTACT_EMAIL ? <>You can contact us at {CONTACT_EMAIL}.</> : <>Contact: [add your email address].</>}</p>

        <h3>What we collect</h3>
        <p>When you take the quiz we collect your answers (what your business sells, offer readiness, advertising experience, platform interest, ad budget range, willingness to invest and decision-making role), your name, email address and WhatsApp number. We also record the campaign details (UTM parameters) of the link that brought you here. If you book a call, Calendly collects the details you enter there.</p>

        <h3>Why we use it</h3>
        <p>To assess your application, decide whether a conversation makes sense, and contact you about it. We use campaign details to understand which ads bring in suitable applicants.</p>

        <h3>Where it's stored</h3>
        <p>Your answers are stored in a private Google Sheet that only we can access. Bookings are handled by Calendly. If you accept tracking, the Meta Pixel sends anonymous usage events (such as page visits) to Meta. We don't send your name, email or phone number to Meta.</p>

        <h3>Your choices</h3>
        <p>Tracking is off unless you accept it in the banner. You can ask us to see, correct or delete the information we hold about you by contacting us. [Add how long you keep applicant information, for example 12 months.]</p>

        <h3>Results disclaimer</h3>
        <p>Advertising results vary and are not guaranteed. Any results shown on this website come from specific campaigns and are not typical.</p>
      </div>
    </main>
  );
}
