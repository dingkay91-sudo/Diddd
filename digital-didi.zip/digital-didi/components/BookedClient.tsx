"use client";

import { useEffect, useState } from "react";
import { track } from "@/lib/track";
import { WHATSAPP_NUMBER } from "@/lib/config";

type Details = { name?: string; when?: string };

export default function BookedClient() {
  const [d, setD] = useState<Details>({});

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const name = p.get("invitee_full_name") || undefined;
    const start = p.get("event_start_time");
    const confirmed = !!(p.get("invitee_uuid") || start);

    let when: string | undefined;
    if (start) {
      const t = new Date(start);
      if (!isNaN(t.getTime())) {
        when = t.toLocaleString("en-NG", { dateStyle: "full", timeStyle: "short" });
      }
    }
    setD({ name, when });

    // Fire only when Calendly sent booking details, and never send them onward.
    if (confirmed) track("Schedule");

    // Remove personal details from the address bar straight away.
    if (window.location.search) window.history.replaceState(null, "", window.location.pathname);
  }, []);

  const lines = ["Hello Didi, I've booked an Ad Growth Opportunity Session."];
  if (d.name || d.when) lines.push("");
  if (d.name) lines.push(`Name: ${d.name}`);
  if (d.when) lines.push(`Appointment: ${d.when}`);
  lines.push("", "I'm looking forward to discussing my business and advertising goals.");
  const message = lines.join("\n");
  const waLink = WHATSAPP_NUMBER ? `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}` : "";

  return (
    <>
      <h1 style={{ fontSize: "clamp(1.9rem, 6vw, 2.8rem)", marginTop: "1.5rem" }}>
        {d.name ? `Thank you, ${d.name.split(" ")[0]}. Your session is booked.` : "Thank you. Your session is booked."}
      </h1>
      <p className="lead">Check your email for the confirmation from Calendly.</p>

      {d.when && (
        <div className="details">
          <p><strong>Your appointment</strong></p>
          <p>{d.when}</p>
        </div>
      )}

      <p>The session is a 15-minute conversation about your business and how we might help. Please be ready to discuss:</p>
      <ul className="next-list">
        <li>Your business and your offer</li>
        <li>Your current advertising situation</li>
        <li>Your goals for the next six weeks</li>
      </ul>

      <h2 style={{ fontSize: "1.5rem", marginTop: "2rem" }}>Message us on WhatsApp</h2>
      {waLink ? (
        <>
          <p>Tap the button to open WhatsApp with a message ready to go. You'll need to tap Send yourself.</p>
          <a className="btn btn-forest" href={waLink} target="_blank" rel="noopener">Continue to WhatsApp</a>
          <p style={{ marginTop: "1rem", color: "var(--muted)" }}>
            If WhatsApp doesn't open, save {"+" + WHATSAPP_NUMBER} and send us a message saying you've booked your session.
          </p>
        </>
      ) : (
        <div className="notice" role="alert">The WhatsApp number isn't set up yet. Check your email for the confirmation, and we'll be in touch.</div>
      )}
    </>
  );
}
