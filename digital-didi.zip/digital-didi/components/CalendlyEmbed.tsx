"use client";

import { useEffect, useState } from "react";
import Script from "next/script";

export default function CalendlyEmbed({ url }: { url: string }) {
  const [src, setSrc] = useState(url);

  // Prefill name and email from the quiz (kept in this browser tab only, never in the page address).
  useEffect(() => {
    try {
      const p = JSON.parse(sessionStorage.getItem("dd_prefill") || "{}");
      const u = new URL(url);
      if (p.name) u.searchParams.set("name", p.name);
      if (p.email) u.searchParams.set("email", p.email);
      u.searchParams.set("hide_gdpr_banner", "1");
      setSrc(u.toString());
    } catch {
      setSrc(url);
    }
  }, [url]);

  return (
    <>
      <div className="cal-box">
        <div className="calendly-inline-widget" data-url={src} style={{ minWidth: 320, height: 720 }} />
      </div>
      <Script src="https://assets.calendly.com/assets/external/widget.js" strategy="lazyOnload" />
      <p style={{ marginTop: "1rem" }}>
        Calendar not loading? <a href={src} target="_blank" rel="noopener">Open it in a new tab</a>.
      </p>
    </>
  );
}
