"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  OFFER_READINESS, ADS_EXPERIENCE, PLATFORM, AD_BUDGET, INVESTMENT, DECISION_MAKER, type Option,
} from "@/lib/quiz-data";
import { track } from "@/lib/track";

type ChoiceKey = "offerReadiness" | "adsExperience" | "platform" | "adBudget" | "investment" | "decisionMaker";
type Answers = Record<ChoiceKey, string> & { sells: string; name: string; email: string; whatsapp: string; consent: boolean };

type Step =
  | { kind: "text"; key: "sells"; title: string; help: string; placeholder: string }
  | { kind: "choice"; key: ChoiceKey; title: string; help?: string; options: Option[] }
  | { kind: "contact" };

const STEPS: Step[] = [
  { kind: "text", key: "sells", title: "What does your business sell?", help: "A short answer is fine.", placeholder: "e.g. Skincare products, solar installation, tailoring" },
  { kind: "choice", key: "offerReadiness", title: "Is your offer ready to sell today?", options: OFFER_READINESS },
  { kind: "choice", key: "adsExperience", title: "Have you run paid ads before?", options: ADS_EXPERIENCE },
  { kind: "choice", key: "platform", title: "Which platform would you want help with?", options: PLATFORM },
  { kind: "choice", key: "adBudget", title: "What is your monthly ad budget, or the budget you plan to use?", help: "A rough range is fine. This helps us understand where you are. It doesn't decide your result.", options: AD_BUDGET },
  { kind: "choice", key: "investment", title: "If we both decide professional support is the right fit, are you prepared to invest in it?", help: "This is separate from the money you spend on the ads themselves.", options: INVESTMENT },
  { kind: "choice", key: "decisionMaker", title: "Are you the person who makes this decision?", options: DECISION_MAKER },
  { kind: "contact" },
];

const EMPTY: Answers = {
  sells: "", offerReadiness: "", adsExperience: "", platform: "", adBudget: "", investment: "", decisionMaker: "",
  name: "", email: "", whatsapp: "", consent: false,
};

const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];

export default function Quiz() {
  const router = useRouter();
  const [i, setI] = useState(0);
  const [a, setA] = useState<Answers>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState<"needs_review" | "not_qualified" | null>(null);
  const [company, setCompany] = useState(""); // honeypot
  const [utm, setUtm] = useState<Record<string, string>>({});
  const started = useRef(false);
  const heading = useRef<HTMLHeadingElement>(null);

  // Capture UTM parameters once and keep them for the whole visit.
  useEffect(() => {
    const found: Record<string, string> = {};
    const params = new URLSearchParams(window.location.search);
    for (const k of UTM_KEYS) {
      const v = params.get(k);
      if (v) found[k] = v;
    }
    if (Object.keys(found).length) sessionStorage.setItem("dd_utm", JSON.stringify(found));
    try { setUtm(JSON.parse(sessionStorage.getItem("dd_utm") || "{}")); } catch { setUtm({}); }
  }, []);

  // Move focus to the new question so keyboard and screen-reader users follow along.
  useEffect(() => {
    if (i > 0 || started.current) heading.current?.focus();
  }, [i, outcome]);

  const step = STEPS[i];
  const total = STEPS.length;

  function begin() {
    if (!started.current) { started.current = true; track("QuizStarted"); }
  }

  function chooseAndAdvance(key: ChoiceKey, value: string) {
    begin();
    setA((p) => ({ ...p, [key]: value }));
    setTimeout(() => setI((n) => Math.min(n + 1, total - 1)), 220);
  }

  function nextFromText() {
    if (a.sells.trim().length < 3) { setErrors({ sells: "Tell us briefly what your business sells." }); return; }
    setErrors({}); begin(); setI(1);
  }

  function clientCheck(): Record<string, string> {
    const e: Record<string, string> = {};
    if (a.name.trim().length < 2) e.name = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(a.email.trim())) e.email = "Enter a valid email address, like name@example.com.";
    if (!/^\+?\d{7,15}$/.test(a.whatsapp.replace(/[\s\-().]/g, ""))) e.whatsapp = "Enter a valid WhatsApp number with country code, like +2348012345678.";
    if (!a.consent) e.consent = "Please tick the box so we can review your answers and contact you.";
    return e;
  }

  async function submit(ev: React.FormEvent) {
    ev.preventDefault();
    setFormError("");
    const e = clientCheck();
    setErrors(e);
    if (Object.keys(e).length) return;

    setBusy(true);
    try {
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...a, company, utm }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 422 && data.errors) {
        setErrors(data.errors);
        // If a quiz answer is invalid, send them back to that question.
        const idx = STEPS.findIndex((s) => s.kind !== "contact" && data.errors[(s as any).key]);
        if (idx >= 0) setI(idx);
        return;
      }
      if (!res.ok) { setFormError(data.error || "Something went wrong on our side. Please try again in a moment."); return; }

      track("QuizCompleted");
      if (data.result === "qualified") {
        sessionStorage.setItem("dd_prefill", JSON.stringify({ name: a.name.trim(), email: a.email.trim() }));
        router.push("/fit");
      } else {
        setOutcome(data.result === "not_qualified" ? "not_qualified" : "needs_review");
      }
    } catch {
      setFormError("We couldn't send your answers. Check your internet connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  if (outcome) {
    return (
      <div className="quiz-shell result" role="status">
        {outcome === "needs_review" ? (
          <>
            <h3 ref={heading} tabIndex={-1}>Thanks. We'll review your answers.</h3>
            <p>We look at each application personally. If a conversation makes sense, we'll contact you on the WhatsApp number or email you gave us.</p>
            <p>Completing the quiz doesn't guarantee a call.</p>
          </>
        ) : (
          <>
            <h3 ref={heading} tabIndex={-1}>Thank you for your honesty.</h3>
            <p>Based on your answers, this six-week engagement may not be the right fit for you at the moment. It's built for business owners who already have something ready to sell and are prepared to invest in professional support.</p>
            <p>If your situation changes, you're welcome to take the quiz again.</p>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="quiz-shell">
      <div className="progress-meta">
        <span>Question {i + 1} of {total}</span>
      </div>
      <div className="progress" role="progressbar" aria-valuemin={1} aria-valuemax={total} aria-valuenow={i + 1} aria-label="Quiz progress">
        <div style={{ width: `${((i + 1) / total) * 100}%` }} />
      </div>

      {step.kind === "text" && (
        <div>
          <h3 className="q-title" ref={heading} tabIndex={-1} id="q-title">{step.title}</h3>
          <p className="q-help">{step.help}</p>
          <div className="field">
            <label htmlFor="sells" className="hp-label" style={{ position: "absolute", left: -9999 }}>{step.title}</label>
            <input
              id="sells" className="input" type="text" maxLength={300} placeholder={step.placeholder}
              value={a.sells} aria-invalid={!!errors.sells} aria-describedby={errors.sells ? "sells-err" : undefined}
              onChange={(e) => setA({ ...a, sells: e.target.value })}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); nextFromText(); } }}
            />
            {errors.sells && <p className="err" id="sells-err">{errors.sells}</p>}
          </div>
          <div className="quiz-nav">
            <button type="button" className="btn btn-forest" onClick={nextFromText}>Continue</button>
          </div>
        </div>
      )}

      {step.kind === "choice" && (
        <fieldset className="opts" aria-labelledby="q-title">
          <legend style={{ padding: 0 }}>
            <h3 className="q-title" ref={heading} tabIndex={-1} id="q-title">{step.title}</h3>
            {step.help && <p className="q-help">{step.help}</p>}
          </legend>
          {errors[step.key] && <p className="err">{errors[step.key]}</p>}
          {step.options.map((o) => (
            <label className="opt" key={o.value}>
              <input
                type="radio" name={step.key} value={o.value}
                checked={a[step.key] === o.value}
                onChange={() => chooseAndAdvance(step.key, o.value)}
                onClick={() => { if (a[step.key] === o.value) chooseAndAdvance(step.key, o.value); }}
              />
              <span>{o.label}</span>
            </label>
          ))}
          <div className="quiz-nav">
            <button type="button" className="link-btn" onClick={() => setI(i - 1)} disabled={i === 0}>Back</button>
            {a[step.key] && i < total - 1 && (
              <button type="button" className="link-btn" onClick={() => setI(i + 1)}>Next</button>
            )}
          </div>
        </fieldset>
      )}

      {step.kind === "contact" && (
        <form onSubmit={submit} noValidate>
          <h3 className="q-title" ref={heading} tabIndex={-1} id="q-title">Last step. Where should we reach you?</h3>
          <p className="q-help">We use this to review your answers and contact you about the session.</p>
          {formError && <div className="form-error" role="alert">{formError}</div>}

          <div className="field">
            <label htmlFor="name">Full name</label>
            <input id="name" className="input" autoComplete="name" value={a.name} aria-invalid={!!errors.name}
              onChange={(e) => setA({ ...a, name: e.target.value })} />
            {errors.name && <p className="err">{errors.name}</p>}
          </div>
          <div className="field">
            <label htmlFor="email">Email address</label>
            <input id="email" className="input" type="email" inputMode="email" autoComplete="email" value={a.email} aria-invalid={!!errors.email}
              onChange={(e) => setA({ ...a, email: e.target.value })} />
            {errors.email && <p className="err">{errors.email}</p>}
          </div>
          <div className="field">
            <label htmlFor="whatsapp">WhatsApp number</label>
            <input id="whatsapp" className="input" type="tel" inputMode="tel" autoComplete="tel" placeholder="+2348012345678" value={a.whatsapp} aria-invalid={!!errors.whatsapp}
              onChange={(e) => setA({ ...a, whatsapp: e.target.value })} />
            <small>Include your country code.</small>
            {errors.whatsapp && <p className="err">{errors.whatsapp}</p>}
          </div>

          {/* Honeypot: hidden from people, tempting to bots */}
          <div className="hp" aria-hidden="true">
            <label>Company <input tabIndex={-1} autoComplete="off" value={company} onChange={(e) => setCompany(e.target.value)} /></label>
          </div>

          <label className="check">
            <input type="checkbox" checked={a.consent} onChange={(e) => setA({ ...a, consent: e.target.checked })} aria-invalid={!!errors.consent} />
            <span>
              I agree that Digital Didi may store my answers and contact me about this application. I've read the{" "}
              <a href="/privacy" target="_blank" rel="noopener">privacy policy</a>.
            </span>
          </label>
          {errors.consent && <p className="err">{errors.consent}</p>}

          <div className="quiz-nav">
            <button type="button" className="link-btn" onClick={() => setI(i - 1)}>Back</button>
            <button type="submit" className="btn btn-forest" disabled={busy} style={{ flex: 1 }}>
              {busy ? "Sending your answers..." : "See my result"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
