"use client";
import { useEffect } from "react";
import { track } from "@/lib/track";

export default function TrackOnMount({ event, when = true }: { event: string; when?: boolean }) {
  useEffect(() => {
    if (when) track(event);
  }, [event, when]);
  return null;
}
