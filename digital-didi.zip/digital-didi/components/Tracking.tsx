"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { META_PIXEL_ID } from "@/lib/config";

const KEY = "dd_tracking_consent";

function loadPixel(id: string) {
  if (window.fbq) return;
  /* Standard Meta Pixel bootstrap */
  (function (f: any, b: Document, e: string, v: string) {
    if (f.fbq) return;
    const n: any = (f.fbq = function () {
      n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
    });
    if (!f._fbq) f._fbq = n;
    n.push = n; n.loaded = true; n.version = "2.0"; n.queue = [];
    const t = b.createElement(e) as HTMLScriptElement;
    t.async = true; t.src = v;
    const s = b.getElementsByTagName(e)[0];
    s.parentNode!.insertBefore(t, s);
  })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
  window.fbq!("init", id);
}

export default function Tracking() {
  const pathname = usePathname();
  const [choice, setChoice] = useState<"yes" | "no" | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(KEY);
    if (saved === "yes" || saved === "no") setChoice(saved);
    setReady(true);
  }, []);

  // Load pixel only after consent, then flush anything queued before consent.
  useEffect(() => {
    if (choice !== "yes" || !META_PIXEL_ID) return;
    loadPixel(META_PIXEL_ID);
    const queued = window.__ddQueue ?? [];
    window.__ddQueue = [];
    for (const [, ev] of queued) {
      window.fbq!(["Lead", "Schedule", "PageView", "ViewContent"].includes(ev) ? "track" : "trackCustom", ev);
    }
  }, [choice]);

  // PageView on each route (the first one fires right after init above).
  useEffect(() => {
    if (choice === "yes" && META_PIXEL_ID && window.fbq) window.fbq("track", "PageView");
  }, [pathname, choice]);

  if (!META_PIXEL_ID || !ready || choice !== null) return null;

  const set = (v: "yes" | "no") => {
    localStorage.setItem(KEY, v);
    setChoice(v);
  };

  return (
    <div className="consent" role="region" aria-label="Cookie and tracking choice">
      <p>
        We use the Meta Pixel to measure which ads bring in applications. It only loads if you accept.
        See our <a href="/privacy">privacy policy</a>.
      </p>
      <div className="row">
        <button className="btn btn-forest" onClick={() => set("yes")}>Accept</button>
        <button className="btn btn-ghost" onClick={() => set("no")}>Decline</button>
      </div>
    </div>
  );
}
