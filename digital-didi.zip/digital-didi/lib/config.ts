// Public-facing settings. Change values in your hosting dashboard (env vars), not in code.
export const BRAND = "Digital Didi";
export const FOUNDER = "Edidiong Emmanuel";

export const CALENDLY_URL = process.env.NEXT_PUBLIC_CALENDLY_URL ?? "";
export const WHATSAPP_NUMBER = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, ""); // digits only, with country code
export const CONTACT_EMAIL = process.env.NEXT_PUBLIC_CONTACT_EMAIL ?? "";
export const META_PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID ?? "";
// Optional capacity line. Leave empty unless it is TRUE, e.g. "Taking 3 new clients this month."
export const CAPACITY_MESSAGE = process.env.NEXT_PUBLIC_CAPACITY_MESSAGE ?? "";
