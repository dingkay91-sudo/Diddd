// Single source of truth for quiz questions. The server validates answers
// against these same option values, so the browser cannot invent new ones.

export type Option = { value: string; label: string };

export const OFFER_READINESS: Option[] = [
  { value: "live", label: "Yes, it's live and people can buy it today" },
  { value: "almost", label: "Almost. It needs some improvement before I scale ads" },
  { value: "none", label: "No, I'm still working out what to sell" },
];

export const ADS_EXPERIENCE: Option[] = [
  { value: "regular", label: "Yes, I run ads regularly" },
  { value: "few", label: "Yes, a few times" },
  { value: "boost", label: "Only boosted posts" },
  { value: "never", label: "Never" },
];

export const PLATFORM: Option[] = [
  { value: "meta", label: "Meta Ads (Facebook and Instagram)" },
  { value: "tiktok", label: "TikTok Ads" },
  { value: "both", label: "Both" },
  { value: "unsure", label: "I'm not sure yet" },
];

// Budget is recorded only. It never qualifies or disqualifies anyone by itself.
// Edit these labels freely; keep the `value` keys unless you update the sheet too.
export const AD_BUDGET: Option[] = [
  { value: "under_100k", label: "Under ₦100,000" },
  { value: "100k_300k", label: "₦100,000 to ₦300,000" },
  { value: "300k_1m", label: "₦300,000 to ₦1,000,000" },
  { value: "over_1m", label: "Above ₦1,000,000" },
  { value: "unsure", label: "I'm not sure yet" },
];

export const INVESTMENT: Option[] = [
  { value: "yes", label: "Yes, I'm prepared to invest in the right support" },
  { value: "understand", label: "I'm interested, but I need to understand what's involved first" },
  { value: "free_only", label: "No, I'm only looking for free guidance" },
];

export const DECISION_MAKER: Option[] = [
  { value: "owner", label: "Yes, I make the decision" },
  { value: "shared", label: "I share the decision with a partner or team" },
  { value: "no", label: "No, I'm enquiring for someone else" },
];

export const VALID: Record<string, string[]> = {
  offerReadiness: OFFER_READINESS.map((o) => o.value),
  adsExperience: ADS_EXPERIENCE.map((o) => o.value),
  platform: PLATFORM.map((o) => o.value),
  adBudget: AD_BUDGET.map((o) => o.value),
  investment: INVESTMENT.map((o) => o.value),
  decisionMaker: DECISION_MAKER.map((o) => o.value),
};

export function labelFor(list: Option[], value: string): string {
  return list.find((o) => o.value === value)?.label ?? value;
}
