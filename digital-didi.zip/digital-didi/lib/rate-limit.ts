// Simple in-memory limiter: max 6 submissions per IP per 10 minutes.
// Note: on serverless hosting each instance has its own memory, so this slows
// casual abuse but is not a hard guarantee. See README for upgrade options.

const WINDOW_MS = 10 * 60 * 1000;
const MAX = 6;
const hits = new Map<string, number[]>();

export function tooMany(ip: string, now = Date.now()): boolean {
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) {
    for (const [k, v] of hits) if (v.every((t) => now - t >= WINDOW_MS)) hits.delete(k);
  }
  return recent.length > MAX;
}
