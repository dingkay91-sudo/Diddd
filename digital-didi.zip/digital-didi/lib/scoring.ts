export type Result = "qualified" | "needs_review" | "not_qualified";

type Answers = { offerReadiness: string; investment: string; decisionMaker: string };

/**
 * Qualification rules. Edit here to change who sees the booking calendar.
 *
 * not_qualified : only wants free guidance, OR has nothing to sell yet
 * qualified     : offer is live/almost ready AND prepared to invest AND has decision authority
 * needs_review  : everything else (e.g. "need to understand first", or enquiring for someone else)
 *
 * Ad budget and ads experience are recorded but never decide the result.
 */
export function score(a: Answers): Result {
  if (a.investment === "free_only" || a.offerReadiness === "none") return "not_qualified";

  const offerOk = a.offerReadiness === "live" || a.offerReadiness === "almost";
  const canDecide = a.decisionMaker === "owner" || a.decisionMaker === "shared";
  if (offerOk && a.investment === "yes" && canDecide) return "qualified";

  return "needs_review";
}
