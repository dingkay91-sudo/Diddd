import type { QuizInput } from "./validate";
import type { Result } from "./scoring";

// Sends one row to the Google Apps Script web app. Returns true only if the
// script confirms it saved the row.
export async function saveToSheet(data: QuizInput, result: Result): Promise<boolean> {
  const url = process.env.GOOGLE_SHEET_WEBHOOK_URL;
  const secret = process.env.GOOGLE_SHEET_SECRET;
  if (!url || !secret) {
    console.error("[sheet] GOOGLE_SHEET_WEBHOOK_URL / GOOGLE_SHEET_SECRET not set; lead NOT saved to sheet.");
    return false;
  }
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        secret,
        name: data.name,
        email: data.email,
        whatsapp: data.whatsapp,
        sells: data.sells,
        offerReadiness: data.offerReadiness,
        adsExperience: data.adsExperience,
        platform: data.platform,
        adBudget: data.adBudget,
        investment: data.investment,
        decisionMaker: data.decisionMaker,
        result,
        ...data.utm,
      }),
      redirect: "follow",
      signal: AbortSignal.timeout(8000),
    });
    const json = await res.json().catch(() => null);
    if (json?.ok === true) return true;
    console.error("[sheet] Apps Script did not confirm save:", JSON.stringify(json));
    return false;
  } catch (err) {
    console.error("[sheet] request failed:", String(err));
    return false;
  }
}
