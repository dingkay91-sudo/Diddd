import { createHmac, timingSafeEqual } from "crypto";

// A signed, expiring "you qualified" pass stored in an httpOnly cookie.
// It contains no personal data.

export const COOKIE_NAME = "dd_pass";
const TTL_SECONDS = 60 * 60 * 6; // 6 hours

function secret(): string {
  const s = process.env.SIGNING_SECRET;
  if (!s || s.length < 16) throw new Error("SIGNING_SECRET is missing or too short (min 16 characters).");
  return s;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function issuePass(now = Date.now()): string {
  const payload = Buffer.from(JSON.stringify({ r: "qualified", exp: Math.floor(now / 1000) + TTL_SECONDS })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function verifyPass(token: string | undefined, now = Date.now()): boolean {
  if (!token) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  try {
    const expected = Buffer.from(sign(payload));
    const given = Buffer.from(sig);
    if (expected.length !== given.length || !timingSafeEqual(expected, given)) return false;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    return data.r === "qualified" && typeof data.exp === "number" && data.exp > Math.floor(now / 1000);
  } catch {
    return false;
  }
}

export const PASS_TTL_SECONDS = TTL_SECONDS;
