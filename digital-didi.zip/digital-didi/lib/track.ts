// Meta Pixel helper. Events are queued until the visitor accepts tracking.
// Never pass names, emails or phone numbers into any event.

const STANDARD = new Set(["PageView", "Lead", "Schedule", "ViewContent"]);

declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
    __ddQueue?: Array<[string, string]>;
  }
}

export function track(event: string) {
  if (typeof window === "undefined") return;
  if (window.fbq) {
    window.fbq(STANDARD.has(event) ? "track" : "trackCustom", event);
  } else {
    (window.__ddQueue ||= []).push(["event", event]);
  }
}
