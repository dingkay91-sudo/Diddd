import { VALID } from "./quiz-data";

export type QuizInput = {
  sells: string;
  offerReadiness: string;
  adsExperience: string;
  platform: string;
  adBudget: string;
  investment: string;
  decisionMaker: string;
  name: string;
  email: string;
  whatsapp: string;
  consent: boolean;
  utm: Record<string, string>;
};

export type FieldErrors = Partial<Record<keyof QuizInput, string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];

// Strips spaces, dashes, brackets. Accepts +234..., 234..., or local 0xxxxxxxxxx.
export function normalisePhone(raw: string): string | null {
  const cleaned = raw.replace(/[\s\-().]/g, "");
  if (!/^\+?\d{7,15}$/.test(cleaned)) return null;
  if (cleaned.startsWith("+")) return cleaned;
  if (/^0\d{10}$/.test(cleaned)) return "+234" + cleaned.slice(1); // Nigerian local format
  return "+" + cleaned; // assume country code was typed without "+"
}

function clean(s: unknown, max: number): string {
  return typeof s === "string" ? s.trim().slice(0, max) : "";
}

export function validate(body: any): { ok: true; data: QuizInput } | { ok: false; errors: FieldErrors } {
  const errors: FieldErrors = {};

  const sells = clean(body?.sells, 300);
  if (sells.length < 3) errors.sells = "Tell us briefly what your business sells.";

  for (const key of Object.keys(VALID)) {
    const v = clean(body?.[key], 40);
    if (!VALID[key].includes(v)) (errors as any)[key] = "Please choose one of the options.";
  }

  const name = clean(body?.name, 100);
  if (name.length < 2) errors.name = "Enter your full name.";

  const email = clean(body?.email, 200).toLowerCase();
  if (!EMAIL_RE.test(email)) errors.email = "Enter a valid email address, like name@example.com.";

  const phone = normalisePhone(clean(body?.whatsapp, 30));
  if (!phone) errors.whatsapp = "Enter a valid WhatsApp number with country code, like +2348012345678.";

  if (body?.consent !== true) errors.consent = "Please tick the box so we can review your answers and contact you.";

  if (Object.keys(errors).length) return { ok: false, errors };

  const utm: Record<string, string> = {};
  for (const k of UTM_KEYS) utm[k] = clean(body?.utm?.[k], 200);

  return {
    ok: true,
    data: {
      sells,
      offerReadiness: clean(body.offerReadiness, 40),
      adsExperience: clean(body.adsExperience, 40),
      platform: clean(body.platform, 40),
      adBudget: clean(body.adBudget, 40),
      investment: clean(body.investment, 40),
      decisionMaker: clean(body.decisionMaker, 40),
      name,
      email,
      whatsapp: phone!,
      consent: true,
      utm,
    },
  };
}
