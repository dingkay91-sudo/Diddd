import { describe, it, expect, beforeAll, vi } from "vitest";
import { NextRequest } from "next/server";

vi.mock("@/lib/sheet", () => ({ saveToSheet: vi.fn(async () => true) }));
import { saveToSheet } from "@/lib/sheet";

let POST: (r: NextRequest) => Promise<Response>;
beforeAll(async () => {
  process.env.SIGNING_SECRET = "test-secret-at-least-16-chars";
  POST = (await import("@/app/api/quiz/route")).POST;
});

const good = {
  sells: "Skincare", offerReadiness: "live", adsExperience: "few", platform: "meta", adBudget: "100k_300k",
  investment: "yes", decisionMaker: "owner", name: "Ada Obi", email: "ada@example.com", whatsapp: "+2348012345678",
  consent: true, utm: { utm_source: "tiktok" },
};

let n = 0;
const req = (body: unknown) =>
  new NextRequest("http://localhost/api/quiz", {
    method: "POST",
    headers: { "x-forwarded-for": `10.0.0.${++n}` },
    body: JSON.stringify(body),
  });

describe("POST /api/quiz", () => {
  it("qualified applicant: saved, gets pass cookie", async () => {
    const res = await POST(req(good));
    const json = await res.json();
    expect(json.result).toBe("qualified");
    expect(res.headers.get("set-cookie")).toContain("dd_pass=");
    expect(saveToSheet).toHaveBeenCalled();
  });
  it("free-guidance applicant: saved, no cookie", async () => {
    const res = await POST(req({ ...good, investment: "free_only" }));
    expect((await res.json()).result).toBe("not_qualified");
    expect(res.headers.get("set-cookie")).toBeNull();
  });
  it("needs-review applicant: no cookie", async () => {
    const res = await POST(req({ ...good, investment: "understand" }));
    expect((await res.json()).result).toBe("needs_review");
    expect(res.headers.get("set-cookie")).toBeNull();
  });
  it("browser cannot choose its own result", async () => {
    const res = await POST(req({ ...good, investment: "free_only", result: "qualified" }));
    expect((await res.json()).result).toBe("not_qualified");
  });
  it("invalid email returns 422 with a message", async () => {
    const res = await POST(req({ ...good, email: "nope" }));
    expect(res.status).toBe(422);
    expect((await res.json()).errors.email).toBeTruthy();
  });
  it("honeypot submissions are not stored and get no pass", async () => {
    vi.mocked(saveToSheet).mockClear();
    const res = await POST(req({ ...good, company: "Acme Bots" }));
    expect(res.headers.get("set-cookie")).toBeNull();
    expect(saveToSheet).not.toHaveBeenCalled();
  });
  it("rate-limits repeated submissions from one IP", async () => {
    const mk = () => new NextRequest("http://localhost/api/quiz", { method: "POST", headers: { "x-forwarded-for": "9.9.9.9" }, body: JSON.stringify({ ...good, investment: "free_only" }) });
    let last = 200;
    for (let i = 0; i < 8; i++) last = (await POST(mk())).status;
    expect(last).toBe(429);
  });
});
