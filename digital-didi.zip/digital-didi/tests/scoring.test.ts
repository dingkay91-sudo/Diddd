import { describe, it, expect } from "vitest";
import { score } from "@/lib/scoring";

const base = { offerReadiness: "live", investment: "yes", decisionMaker: "owner" };

describe("score", () => {
  it("qualifies a ready, willing decision-maker", () => expect(score(base)).toBe("qualified"));
  it("qualifies an almost-ready offer", () => expect(score({ ...base, offerReadiness: "almost" })).toBe("qualified"));
  it("qualifies a shared decision-maker", () => expect(score({ ...base, decisionMaker: "shared" })).toBe("qualified"));
  it("rejects free-guidance-only", () => expect(score({ ...base, investment: "free_only" })).toBe("not_qualified"));
  it("rejects when there is nothing to sell", () => expect(score({ ...base, offerReadiness: "none" })).toBe("not_qualified"));
  it("sends 'need to understand first' to review, not rejection", () => expect(score({ ...base, investment: "understand" })).toBe("needs_review"));
  it("sends non-decision-makers to review", () => expect(score({ ...base, decisionMaker: "no" })).toBe("needs_review"));
});
