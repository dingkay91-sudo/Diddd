import { describe, it, expect, beforeAll } from "vitest";
import { issuePass, verifyPass } from "@/lib/token";

beforeAll(() => { process.env.SIGNING_SECRET = "test-secret-at-least-16-chars"; });

describe("pass token", () => {
  it("verifies a fresh pass", () => expect(verifyPass(issuePass())).toBe(true));
  it("rejects missing or garbage tokens", () => {
    expect(verifyPass(undefined)).toBe(false);
    expect(verifyPass("abc.def")).toBe(false);
    expect(verifyPass("nodot")).toBe(false);
  });
  it("rejects a tampered payload", () => {
    const [p, s] = issuePass().split(".");
    const forged = Buffer.from(JSON.stringify({ r: "qualified", exp: 9999999999 })).toString("base64url");
    expect(verifyPass(`${forged}.${s}`)).toBe(false);
    expect(p).toBeTruthy();
  });
  it("rejects an expired pass", () => {
    const old = issuePass(Date.now() - 1000 * 60 * 60 * 24);
    expect(verifyPass(old)).toBe(false);
  });
});
