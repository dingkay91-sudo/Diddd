import { describe, it, expect } from "vitest";
import { validate, normalisePhone } from "@/lib/validate";

const good = {
  sells: "Skincare", offerReadiness: "live", adsExperience: "few", platform: "meta", adBudget: "100k_300k",
  investment: "yes", decisionMaker: "owner", name: "Ada Obi", email: "ADA@Example.com", whatsapp: "+234 801 234 5678",
  consent: true, utm: { utm_source: "tiktok", utm_campaign: "oct", junk: "x" },
};

describe("validate", () => {
  it("accepts a good submission and normalises it", () => {
    const r = validate(good);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.data.email).toBe("ada@example.com");
      expect(r.data.whatsapp).toBe("+2348012345678");
      expect(r.data.utm.utm_source).toBe("tiktok");
      expect((r.data.utm as any).junk).toBeUndefined();
    }
  });
  it("rejects a bad email", () => {
    const r = validate({ ...good, email: "not-an-email" });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.email).toBeTruthy();
  });
  it("rejects missing consent", () => expect(validate({ ...good, consent: false }).ok).toBe(false));
  it("rejects invented option values", () => expect(validate({ ...good, investment: "hacked" }).ok).toBe(false));
  it("rejects missing required fields", () => expect(validate({}).ok).toBe(false));
  it("handles malformed input types", () => expect(validate({ ...good, name: 123, sells: ["x"] }).ok).toBe(false));
});

describe("normalisePhone", () => {
  it("converts Nigerian local format", () => expect(normalisePhone("08012345678")).toBe("+2348012345678"));
  it("keeps + numbers", () => expect(normalisePhone("+44 7700 900123")).toBe("+447700900123"));
  it("rejects junk", () => expect(normalisePhone("abc")).toBeNull());
});
